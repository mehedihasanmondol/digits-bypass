<?php
function last_sent_from_successful($message_descriptions, $successful) {
    return true;
}

function last_sent_from_failed($message_descriptions, $failed) {
    return false;
}
